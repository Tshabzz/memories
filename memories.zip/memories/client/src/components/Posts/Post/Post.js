import useStyles from './styles'

const Post = () => {
    return (
        <h1>Form</h1>
    );
}

export default Post;