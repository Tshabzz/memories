
import postRoute from "./posts.js";

const routes = [
    postRoute
]


export default routes